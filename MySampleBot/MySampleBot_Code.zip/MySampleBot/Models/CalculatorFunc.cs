﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MySampleBot.Models
{
    public enum CalculatorFunc
    {
        Default,
        Add,
        Subtract,
        Multiply,
        Divide
    }
}